from discord.ext import commands

ALLOWED_USERNAMES = ["haniparo", "dankastur"]

def is_allowed_user():
    def predicate(ctx):
        return ctx.author.name.lower() in [u.lower() for u in ALLOWED_USERNAMES]
    return commands.check(predicate)
