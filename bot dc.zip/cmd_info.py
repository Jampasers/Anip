from discord.ext import commands

def setup(bot, c, conn, fmt_wl, PREFIX):
    @bot.command(usage=f"{PREFIX}info")
    async def info(ctx):
        c.execute("SELECT nama, balance FROM users WHERE user_id = ?", (ctx.author.id,))
        row = c.fetchone()
        if row:
            await ctx.send(
                f"```📦 Profile\n"
                f"--------------------------\n"
                f"Name    : {row[0]}\n"
                f"Balance : {fmt_wl(row[1])} WL```"
            )
        else:
            await ctx.send("You are not registered.")
